﻿using System.Windows.Controls;

namespace SampleWpf2025.Components
{
    /// <summary>
    /// Логика взаимодействия для Number.xaml
    /// </summary>
    public partial class Number : UserControl
    {
        public Number()
        {
            InitializeComponent();
        }
    }
}
