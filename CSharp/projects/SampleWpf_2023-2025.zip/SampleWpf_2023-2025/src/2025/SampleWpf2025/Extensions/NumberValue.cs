﻿namespace SampleWpf2025.Extensions;

public enum NumberValue
{
    Less55,
    Less70,
    Less86,
    Perfect,
    Error
}