﻿namespace SampleWpf2024.Converters;

public enum NumberValue
{
    LessZero,
    Zero,   
    UpperZero
}   